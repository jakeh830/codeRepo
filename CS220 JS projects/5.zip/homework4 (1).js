class FluentRestaurants {
  constructor(jsonData) {
    this.data = jsonData;
  }
  //returns a new FluentRestaurant object with data that only contains restaurants found within
  //the state passed as input
  //fromState(stateStr: String): FluentRestaurant
  fromState(stateStr) {
    return new FluentRestaurants(this.data.filter(e => {
      return lib220.getProperty(e, 'state').found && e.state === stateStr;
    }));
  }
  //returns a new FluentRestaurant object with data that only contains restaurants with a star rating
  //less than or equal to the passed value
  //ratingLeq(rating: number): FluentRestaurant
  ratingLeq(rating) {
    return new FluentRestaurants(this.data.filter(e => {
      return lib220.getProperty(e, 'stars').found && e.stars <= rating;
    }));
  }
  //returns a new FluentRestaurant object with data that only contains restaurants with a star rating
  //greater than or equal to the passed value
  //ratingGeq(rating: number): FluentRestaurant
  ratingGeq(rating) {
    return new FluentRestaurants(this.data.filter(e => {
      return lib220.getProperty(e, 'stars').found && e.stars >= rating;
    }));
  }
  //returns a new FluentRestaurant object with data that only contains restaurants that contain a category
  //equal to the input String
  //category(categoryStr: String): FluentRestaurant
  category(categoryStr) {
    return new FluentRestaurants(this.data.filter(e => {
      return (lib220.getProperty(e, 'categories').found && e.categories.indexOf(categoryStr) > -1);
    }));
  }
  //returns a new FluentRestaurant object with data that only contains restaurants that contain a String
  //within Ambience that is equal to the input String and also return true
  //hasAmbience(ambienceStr: String): FluentRestaurant
  hasAmbience(ambienceStr) {
    return new FluentRestaurants(this.data.filter(e => {
      if (lib220.getProperty(e, 'attributes').found && lib220.getProperty(e.attributes, 'Ambience').found && lib220.getProperty(e.attributes.Ambience, ambienceStr).found) {
        return lib220.getProperty(e.attributes.Ambience, ambienceStr).value;
      }
      return false;
    }));
  }
  //returns the restaurant with the highest stars, if there is a tie, then the one with the most reviews, failiing that, then the first one
  //returns an empty object if no such restaurant is found
  //bestPlace(): Restaurant
  bestPlace() {
    let maxStarsList = createMaxStarsList(this);
    if (maxStarsList.length < 2) { return firstCheck(maxStarsList); }
    let maxReviewList = createMaxReviewCountList(maxStarsList);
    return secondCheck(maxReviewList);
  }
  //returns the restaurant with the most reviews, if there is a tie then the one with the most stars, failing that, then the first one
  //returns an empty object if no such restaurant is found
  //mostReviews(): Restaurant
  mostReviews() {
    let maxReviewList = createMaxReviewCountList(this.data);
    if (maxReviewList.length < 2) { return firstCheck(maxReviewList); }
    let maxStarsList = createMaxStarsList(new FluentRestaurants(maxReviewList));
    return secondCheck(maxStarsList);
  }
}

//helper functions

//function to be passed into reduce when searching for highest star rating
//findMaxStars(acc: number, elem: Restaurant): number
function findMaxStars(acc, elem) {
  if (lib220.getProperty(elem, 'stars').found && elem.stars > acc) {
    return elem.stars;
  }
  else {
    return acc;
  }
}
//function to be passed into reduce when searching for highest review count
//findMaxReviews(acc: number, elem: Restaurant): number
function findMaxReviews(acc, elem) {
  if (lib220.getProperty(elem, 'review_count').found && elem.review_count > acc) {
    return elem.review_count;
  }
  return acc;
}
//creates and returns an array of Restaurant objects from data that have a review count
//equal to the maximum review count value found within data
//createMaxReviewCountList(data: Restaurant[]): Restaurant[]
function createMaxReviewCountList(data) {
  let maxReview = data.reduce(findMaxReviews, 0);
  return data.filter(e => {
      return (lib220.getProperty(e, 'review_count').found && e.review_count >= maxReview);
    });
}
//creates and returns an array of Restaurant objects from data that have a star count
//equal to the maximum star value found within data
//createMaxStarsList(flObj: FluentRestaurants): Restaurant[]
function createMaxStarsList(flObj) {
  let maxStars = flObj.data.reduce(findMaxStars,0);
  return flObj.ratingGeq(maxStars).data;
}
//helper function for bestPlace() and mostReviews(), performs a preliminary check
//on which Restaurant should be returned, if any at all
//firstCheck(list: Restaurant[]): Restaurant
function firstCheck(list) {
  if (list.length === 1) { return list[0]; }
  return {};
}
//helper function for bestPlace() and mostReviews(), after performing a seconding sorting, if firstCheck() yields
//no certain Restaurant, this function will perform a final check to determine which Restaurant should be returned
//secondCheck(list: Restaurant[]): Restaurant
function secondCheck(list) {
  if (list.length === 0) { return {}; }
  return list[0]; 
}

//test data sets

const testData = [
{
  name: "R1",
  state: "MA",
  stars: 4,
  review_count: 6,
  categories: ["Italian", "Outdoor"]
},
{
  name: "R2",
  state: "MA",
  stars: 4,
  review_count: 10,
  categories: ["Chinese", "Outdoor"]
},
{
  name: "R3",
  state: "MA",
  stars: 2,
  review_count: 3,
  categories: ["Chinese", "Indoor"]
},
{
  name: "R4",
  state: "MA",
  stars: 3,
  review_count: 90,
  categories: [],
  attributes: {
    Ambience: {
      goth: false,
    }
  }
},
{
  name: "R5",
  state: "MA",
  stars: 1,
  review_count: 5,
  attributes: {
    Ambience:  {
      hipster: false,
      goth: true,
    }
  }
},
{
  name: "R6",
  state: "RI",
  stars: 5,
  review_count: 10,
  attributes: {
    Ambience: {}
  }
},
{
  name: "R7",
  state: "RI",
  stars: 4,
  review_count: 20,
},
{
  name: "R8",
  state: "RI",
  stars: 2,
  review_count: 400,
  attributes: {
    Ambience: {
      goth: true,
      casuel: false,
    }
  }
},
{
  name: "R9",
  state: "RI",
  stars: 2,
  review_count: 0,
  attributes: {}
},
{
  name: "R10",
  state: "CT",
  stars: 0,
  review_count: 1,
}
]
const testData2 = [
{
  name: "T1",
  state: "AZ",
  stars: 2,
  review_count: 5,
},
{
  name: "T2",
  state: "AZ",
  stars: 2,
  review_count: 10,
},
{
  name: "T3",
  state: "FL",
  stars: 2,
  review_count: 5,
},
{
  name: "T4",
  state: "FL",
  stars: 3,
  review_count: 5,
},
{
  name: "T5",
  state: "TX",
  stars: 5,
},
{
  name: "T6",
  state: "TX",
  stars: 5,
  review_count: 1,
}
]
const testData3 = [
{
  name: "Z1"
},
{
  name: "Z2",
  state: "NJ"
}
]

//tests

let tObj = new FluentRestaurants(testData);
let tObj2 = new FluentRestaurants(testData2);
let tObj3 = new FluentRestaurants(testData3);

test('fromState- works correctly' , function() {
  let list = tObj.fromState('MA').data;
  let list2 = tObj.fromState('CT').data;
  let list3 = tObj.fromState('NY').data;
  assert(list[1].name === "R2" && list.length === 5);
  assert(list2[0].name === "R10" && list2.length === 1);
  assert(list3.length === 0);
});
test('ratingLeq- works correctly' , function() {
  let list = tObj.ratingLeq(1).data;
  let list2 = tObj.ratingLeq(5).data;
  assert(list.length === 2 && list[0].name === "R5");
  assert(list2.length === 10 && list2[0].name === "R1");
});
test('ratingGeq- works correctly' , function() {
  let list = tObj.ratingGeq(5).data;
  let list2 = tObj.ratingGeq(1).data;
  assert(list.length === 1 && list[0].name === "R6");
  assert(list2.length === 9 && list2[0].name === "R1");
});
test('category- works correctly' , function() {
  let list = tObj.category("Chinese").data;
  let list2 = tObj.category("Indoor").data;
  assert(list.length === 2 && list[0].name === "R2");
  assert(list2.length === 1 && list2[0].name === "R3");
});
test('hasAmbience- works correctly' , function() {
  let list = tObj.hasAmbience("goth").data;
  assert(list.length === 2 && list[0].name === "R5");
});
test('bestPlace- works correctly' , function() {
  let bestPlace = tObj2.bestPlace();
  let bestPlace2 = tObj2.fromState("AZ").bestPlace();
  let bestPlace3 = tObj2.fromState("FL").bestPlace();
  assert(bestPlace.name === "T6");
  assert(bestPlace2.name === "T2");
  assert(bestPlace3.name === "T4");
});
test('mostReviews- works correctly' , function() {
  let mostReviews = tObj2.mostReviews();
  let mostReviews2 = tObj2.fromState("AZ").mostReviews();
  let mostReviews3 = tObj2.fromState("FL").mostReviews();
  assert(mostReviews.name === "T2");
  assert(mostReviews2.name === "T2");
  assert(mostReviews3.name === "T4");
});
test('bestPlace and mostReviews return empty object when no best is found' , function() {
  let best = tObj3.bestPlace();
  let most = tObj3.mostReviews();
  assert(Object.keys(best).length === 0);
  assert(Object.keys(most).length === 0);
});