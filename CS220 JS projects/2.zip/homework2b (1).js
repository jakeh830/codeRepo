/*takes in an image and a function, creates a copy of inputted image, and iterates over each pixel of the copy, 
applying the input function to each of them, then returns the copy image*/
//imageMapXY(img: Image, func: (img: Image, x: number, y: number) => Pixel):Image
function imageMapXY(img, func) {
  let outImg = img.copy();
  for (let i = 0; i < outImg.width; ++i) {
    for (let j = 0; j < outImg.height; ++j) {
      outImg.setPixel(i,j, func(img, i, j));
    }
  }
  return outImg;
}

/*Takes in an image, conditional function, and Pixel.  Returns a new image using imageMapXY to map over every pixel, 
changing each pixel to maskValue if the conditional function returns true at that pixel, or leaving the pixel
unchanged from the original image if it (the conditional) returns false.*/
//imageMask(img: Image, cond: (img: Image, x: number, y: number) => boolean,maskValue: Pixel): Image
function imageMask(img, cond, maskValue) {
  function sendToMap(img, x, y) {
    if (cond(img,x,y)) {
      return maskValue;
    }
    else {
      return img.getPixel(x,y);
    }
  }
  return imageMapXY(img, sendToMap);
}

/*Works the same as imageMask with the slight change that if the conditional function returns true, then the pixel at
that point is changed to the pixel returned by function func, which takes in the original pixel as input*/
//imageMapCond(img: Image, cond: (img: Image, x: number, y: number) => boolean, func: (p: Pixel) => Pixel): Image
function imageMapCond(img, cond, func) {
  function sendToMap(img, x, y) {
    if (cond(img,x,y)) {
      return func(img.getPixel(x,y));
    }
    else {
      return img.getPixel(x,y);
    }
  }
  return imageMapXY(img, sendToMap);
}

/*takes in an image, as well as coordinates. Returns a pixel with values averaged out 
from values of all valid pixels neighboring (x,y) as well as (x,y) itself*/
//blurPixel(img: Image, x: number, y: number): Pixel
function blurPixel(img, x, y) {
  let adjPixels = determineNeighbors(x, y, img);
  function getMean(i) {
    return adjPixels.reduce(((total, elem) => total + elem[i]), 0) / adjPixels.length;
  }
  return [getMean(0),getMean(1),getMean(2)];
}

/*takes in image, then uses imageMapXY to create a copy image and apply blurPixel to each pixel of it, 
then returns said image*/
//blurImage(img: Image): Image
function blurImage(img) {
  return imageMapXY(img, blurPixel);
}

/*Helper function for blurPixel - takes the coordinates of a pixel along with an image, determines the 
valid neighbors of the pixel at those coordinates, and returns the neighboring pixels in an array*/
//determineNeighbors(i: number, k: number, img: image): Pixel[]
function determineNeighbors(i, k, img) {
  let neighbors = [img.getPixel(i,k)];
  let iPlus = (i+1 < img.width);
  let iMinus = (i-1 > -1);
  let kPlus = (k+1 < img.height);
  let kMinus  = (k-1 > -1);
  if (iPlus)            {neighbors.push(img.getPixel(i+1, k));}
  if (iMinus)           {neighbors.push(img.getPixel(i-1, k))};
  if (kPlus)            {neighbors.push(img.getPixel(i, k+1));}
  if (kMinus)           {neighbors.push(img.getPixel(i, k-1));}
  if (iPlus && kPlus)   {neighbors.push(img.getPixel(i+1, k+1));}
  if (iPlus && kMinus)  {neighbors.push(img.getPixel(i+1, k-1));}
  if (iMinus && kPlus)  {neighbors.push(img.getPixel(i-1, k+1));}
  if (iMinus && kMinus) {neighbors.push(img.getPixel(i-1, k-1));}
  return neighbors;
}

//2b functions

/*Takes in an image and a boolean, if boolean is true, then it will return
a new image that is blurred only on the left side, if false then it will
return a new image only blurred on the right side.*/
//blurHalfImage(img: Image, left: boolean): Image
function blurHalfImage(img, left) {
  let blurHalf = function(img,x,y) {
    let shouldBlur = ((!left && x >= img.width/2) || (left && x < img.width/2));
    return (shouldBlur) ? blurPixel(img,x,y) : img.getPixel(x,y);
  }
  return imageMapXY(img, blurHalf);
}

/*Checks is a pixel is grayish, returns a boolean true if yes, false otherwise*/
//isGrayish(p: Pixel): boolean
function isGrayish(p) {
  let max = Math.max(p[0],p[1],p[2]);
  let min = Math.min(p[0],p[1],p[2]);
  return (Math.abs(max-min) <= (1/3));
}

/*Takes in an image and returns a new image where each pixel that is NOT
grayish will be made grayscale, and grayish pixels will be untouched*/
//makeGrayish(img: Image): Image
function makeGrayish(img) {
  return imageMapCond(img, (img,x,y) => true, grayPixel);
}

/*Takes in a pixel and returns a grayscale of that pixel*/
//grayPixel(p: Pixel): Pixel
function grayPixel(p) {
  let m = (p[0]+p[1]+p[2]) / 3;
  return (isGrayish(p)) ? p : [m,m,m];
}

/*Takes in an image and returns a new image that is a copy where the top
half has been grayed out, and the bottom remains in color*/
//grayHalfImage(img: Image): Image
function grayHalfImage(img) {
  function cond(img,x,y) {return (!isGrayish(img.getPixel(x,y)) && y < img.height/2);}
  return imageMapCond(img,cond,grayPixel);
}

/*Takes in an image and returns a copy where the colors have been saturated*/
//saturateHigh(img: Image): Image
function saturateHigh(img) {
  return imageMapCond(img, (img,x,y) => true, saturatePixel);
}

/*Takes in a pixel and returns a saturated version of that pixel*/
//saturatePixel(p: Pixel): Pixel
function saturatePixel(p) {
  function sat(val) {return (val > 2/3) ? 1 : val;}
  return [sat(p[0]), sat(p[1]), sat(p[2])];
}

/*Takes in an image and returns a copy where all low pixel values
have been made completely black*/
//blackenLow(img: Image): Image
function blackenLow(img) {
  return imageMapCond(img, (img,x,y) => true, blackenPixel);
}

/*Takes in a pixel and returns a blackened version of that pixel
if it needs to be blackened, otherwise returns input pixel*/
//blackenPixel(p: Pixel): Pixel
function blackenPixel(p) {
  function blacken(val) {return (val < 1/3) ? 0 : val;}
  return [blacken(p[0]), blacken(p[1]), blacken(p[2])];
}

/*Takes in an array of pixel editing functions and returns a function that
will apply all of them to a pixel, which itself (the returned function) will return a new pixel.*/
//reduceFunctions(fa: ((p: Pixel) => Pixel)[] ): ((x: Pixel) => Pixel)
function reduceFunctions(fa) {
  return (pixel) => (fa.reduce(((acc, elem) => elem(acc)), pixel));
}

/*Takes in an image and returns a copy which is equivalent to if the same image
was put through saturateHigh, blackenLow, and makeGrayish (in that order) */
//contrastGray(img: Image): Image
function contrastGray(img) {
  return imageMapCond(img, (img,x,y) => true, reduceFunctions([saturatePixel, blackenPixel, grayPixel]));
}

//test functions

//takes in 2 pixels and returns true if they equal in value and false otherwise
//pixelEq(p1: Pixel, p2: Pixel): boolean
function pixelEq (p1 , p2) {
  const epsilon = 0.002;
  for (let i = 0; i < 3; ++i) {
    if (Math.abs(p1[i] - p2[i]) > epsilon) {
      return false;
    }
  }
  return true;
}

/*helper test function that takes in an array of pixel values, adds them to an image then alters the image 
using the given function (func) and compares to another array of predicted new pixel values for the image*/
//testValues(func: (img) => img, iArr: Pixel[], oArr: Pixel[])
function testValues(func, iArr, oArr) {
  let img = lib220.createImage(3,1,[1,1,1]);
  img.setPixel(0,0, iArr[0]);
  img.setPixel(1,0, iArr[1]);
  img.setPixel(2,0, iArr[2]);
  img = func(img);
  for (let i = 0; i < oArr.length; ++i) {
    assert(pixelEq(img.getPixel(i,0), oArr[i]));
  }
}

//homework 2b tests

test('contrastGray - returns same image as saturateHigh then blackenLow then makeGrayish' , function () {
  const img = lib220.loadImageFromURL('https://people.cs.umass.edu/~joydeepb/robot.jpg');
  let img1 = contrastGray(img);
  let img2 = saturateHigh(img);
  img2 = blackenLow(img2);
  img2 = makeGrayish(img2);
  let arr = [[0,0],[12,24],[40,0],[150,130],[300,200]];
  let checkCoords = (acc, elem) => (pixelEq(img1.getPixel(elem[0], elem[1]), img2.getPixel(elem[0], elem[1]))) ? true : false;
  assert(arr.reduce(checkCoords,false));
});

test('blurHalfImage - returns image with either left or right equal to blurImage with the other half being unblurred' , function () {
  const img = lib220.createImage(40,1,[1,1,1]);
  let xHalf = img.width/2;
  let arr = [[1,0],[xHalf-1,0],[xHalf,0],[30,0]];
  for (let i = 0; i < arr.length; ++i) {
    img.setPixel(arr[i][0], arr[i][1], [0,0,0]);
  }
  let img1 = blurImage(img);
  let img2 = blurHalfImage(img, true);
  let img3 = blurHalfImage(img, false);
  for (let i = 0; i < arr.length; ++i) {
    if (i < arr.length/2) {
      assert(pixelEq(img1.getPixel(arr[i][0], arr[i][1]), img2.getPixel(arr[i][0], arr[i][1])) && !pixelEq(img1.getPixel(arr[i][0], arr[i][1]), img3.getPixel(arr[i][0], arr[i][1])));
    } 
    else {
      assert(!pixelEq(img1.getPixel(arr[i][0], arr[i][1]), img2.getPixel(arr[i][0], arr[i][1])) && pixelEq(img1.getPixel(arr[i][0], arr[i][1]), img3.getPixel(arr[i][0], arr[i][1])));
    }
  }
});

test('isGrayish - correctly returns if a pixel is grayish' , function() {
  let pArr = [[0,0,0], [1,0,0], [0.5,0.8,0.6], [0.5,0.85,0.6], [0,0,(1/3)], [0,0,(1.0001/3)]];
  for (let i = 0; i < pArr.length; ++i) {
    if (i%2 === 0) {
      assert(isGrayish(pArr[i]));
    }
    else {
      assert(!isGrayish(pArr[i]));
    }
  }
});

test('makeGrayish - correctly grays an image' , function() {
  let iArr = [[0,0,0], [0.2,1,0.6], [1,0,0.5]];
  let oArr = [[0,0,0], [0.6,0.6,0.6], [0.5,0.5,0.5]];
  testValues(makeGrayish, iArr, oArr);
});

test('grayHalfImage - correctly grays half (and only half) of an image' , function() {
  let img = lib220.createImage(1,10,[1,0,0]);
  img = grayHalfImage(img);
  let pArr = [img.getPixel(0,0), img.getPixel(0,(img.height/2)-1), img.getPixel(0,img.height/2), img.getPixel(0,9)];
  for (let i = 0; i < pArr.length; ++i) {
    if (i < pArr.length/2) {
      assert(isGrayish(pArr[i]));
    }
    else {
      assert(!isGrayish(pArr[i]));
    }
  }
});

test('saturateHigh - correctly saturates an image' , function() {
  let iArr = [[0,0,0], [(2/3),0.65,0.67], [1,0.8,0.5]];
  let oArr = [[0,0,0], [(2/3),0.65,1], [1,1,0.5]];
  testValues(saturateHigh, iArr, oArr);
});

test('blackenLow - correctly blackens an image' , function() {
  let iArr = [[0,1,1], [(1/3),0.34,0.32], [0.2,0.3,0.5]];
  let oArr = [[0,1,1], [(1/3),0.34,0], [0,0,0.5]];
  testValues(blackenLow, iArr, oArr);
});
