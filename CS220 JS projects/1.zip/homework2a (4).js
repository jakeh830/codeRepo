/*takes in an image and a function, creates a copy of inputted image, and iterates over each pixel of the copy, 
applying the input function to each of them, then returns the copy image*/
//imageMapXY(img: Image, func: (img: Image, x: number, y: number) => Pixel):Image
function imageMapXY(img, func) {
  let outImg = img.copy();
  for (let i = 0; i < outImg.width; ++i) {
    for (let j = 0; j < outImg.height; ++j) {
      outImg.setPixel(i,j, func(img, i, j));
    }
  }
  return outImg;
}
/*Takes in an image, conditional function, and Pixel.  Returns a new image using imageMapXY to map over every pixel, 
changing each pixel to maskValue if the conditional function returns true at that pixel, or leaving the pixel
unchanged from the original image if it (the conditional) returns false.*/
//imageMask(img: Image, cond: (img: Image, x: number, y: number) => boolean,maskValue: Pixel): Image
function imageMask(img, cond, maskValue) {
  function sendToMap(img, x, y) {
    if (!(cond(img,x,y))) {
      return img.getPixel(x,y);
    }
    else {
      return maskValue;
    }
  }
  return imageMapXY(img, sendToMap);
}

/*Works the same as imageMask with the slight change that if the conditional function returns true, then the pixel at
that point is changed to the pixel returned by function func, which takes in the original pixel as input*/
//imageMapCond(img: Image, cond: (img: Image, x: number, y: number) => boolean, func: (p: Pixel) => Pixel): Image
function imageMapCond(img, cond, func) {
  function sendToMap(img, x, y) {
    if (!(cond(img,x,y))) {
      return img.getPixel(x,y);
    }
    else {
      return func(img.getPixel(x,y));
    }
  }
  return imageMapXY(img, sendToMap);
}

/*takes in an image, as well as coordinates. Returns a pixel with values averaged out 
from values of all valid pixels neighboring (x,y) as well as (x,y) itself*/
//blurPixel(img: Image, x: number, y: number): Pixel
function blurPixel(img, x, y) {
  let adjPixels = determineNeighbors(x, y, img);
  function getMean(i) {
    return adjPixels.reduce(((total, elem) => total + elem[i]), 0) / adjPixels.length;
  }
  return [getMean(0),getMean(1),getMean(2)];
}

/*takes in image, then uses imageMapXY to create a copy image and apply blurPixel to each pixel of it, 
then returns said image*/
//blurImage(img: Image): Image
function blurImage(img) {
  return imageMapXY(img, blurPixel);
}

/*Helper function for blurPixel - takes the coordinates of a pixel along with an image, determines the 
valid neighbors of the pixel at those coordinates, and returns the neighboring pixels in an array*/
//determineNeighbors(i: number, k: number, img: image): Pixel[]
function determineNeighbors(i, k, img) {
  let neighbors = [img.getPixel(i,k)];
  let iPlus = (i+1 < img.width);
  let iMinus = (i-1 > -1);
  let kPlus = (k+1 < img.height);
  let kMinus  = (k-1 > -1);
  if (iPlus)            {neighbors.push(img.getPixel(i+1, k));}
  if (iMinus)           {neighbors.push(img.getPixel(i-1, k))};
  if (kPlus)            {neighbors.push(img.getPixel(i, k+1));}
  if (kMinus)           {neighbors.push(img.getPixel(i, k-1));}
  if (iPlus && kPlus)   {neighbors.push(img.getPixel(i+1, k+1));}
  if (iPlus && kMinus)  {neighbors.push(img.getPixel(i+1, k-1));}
  if (iMinus && kPlus)  {neighbors.push(img.getPixel(i-1, k+1));}
  if (iMinus && kMinus) {neighbors.push(img.getPixel(i-1, k-1));}
  return neighbors;
}

//takes in 2 pixels and returns true if they equal in value and false otherwise
//pixelEq(p1: Pixel, p2: Pixel): boolean
function pixelEq (p1 , p2) {
  const epsilon = 0.002;
  for (let i = 0; i < 3; ++i) {
    if (Math.abs(p1[i] - p2[i]) > epsilon) {
      return false;
    }
  }
  return true;
}

/*helper function for tests dealing with blurImage and blurPixel.  Takes an image and array of coordinates 
(number arrays) and paints said coordinate points on image as black, then outputs true if the blur function has successfully 
blurred the 4 symmetrical points (often of corners or opposite sides) AND has done so evenly.  Note that this function should 
only be used with SYMMETRICAL image and points, of which all chosen points (p) should be intended to be blurred to the same value*/
//blurHelper(img: Image, p: number[][]): boolean
function blurTestHelper(img, p) {
  let cornersBlurred = false;
  let cornersEqual = false;
  let imgArr = [];
  let outArr = [];
  for (let i = 0; i < p.length; ++i) {
    img.setPixel(p[i][0], p[i][1], [0,0,0]);
  }
  const outImg = blurImage(img);
  for (let i = 0; i < p.length; ++i) {
    imgArr.push(img.getPixel(p[i][0], p[i][1]));
    outArr.push(outImg.getPixel(p[i][0], p[i][1]));
    //checks that all corners/opposite sides are blurred
    if(!pixelEq(imgArr[i], outArr[i])) {
      cornersBlurred = true;
    }
  }
  //checks that all corners/opposite sides are equal (assumes the input image is symmterical)
  if (pixelEq(outArr[0], outArr[1]) && pixelEq(outArr[2], outArr[3]) && pixelEq(outArr[0], outArr[3])) {
    cornersEqual = true;
  }
  return (cornersBlurred && cornersEqual);
}

test('blurImage/blurPixel - check all corners are blurred equally given symmetrical image' , function() {
  const img = lib220.createImage(9,9,[1,1,1]);
  let corners = [[0,0], [8,0], [0,8], [8,8]];
  assert(blurTestHelper(img, corners));
});

test('blurImage/blurPixel - check all opposite sides are blurred equally given symmetrical image' , function() {
  const img = lib220.createImage(9,9,[1,1,1]);
  let sides = [[0,4], [8,4], [4,0], [4,8]];
  assert(blurTestHelper(img, sides));
});

test('blurImage and blurPixel each return the same pixel values for a point on an identical image' , function() {
  const img = lib220.createImage(3,3,[0.2,0.3,0.4]);
  const img2 = lib220.createImage(3,3,[0.2,0.3,0.4]);
  let pixel = blurPixel(img, 1, 1);
  let pixel2 = blurImage(img).getPixel(1,1);
  assert(pixelEq(pixel, pixel2));
});

test('blurImage - can return a single pixel image' , function() {
  const img = lib220.createImage(1,1,[0.5,0.5,0.5]);
  const outImg = blurImage(img);
  assert(pixelEq([0.5,0.5,0.5], outImg.getPixel(0,0)));
});

test ('imageMapXY correctly changes & returns a single pixel image' , function() {
  const img = lib220.createImage(1,1,[0,0,0]);
  assert(pixelEq([1,1,1], imageMapXY(img, (img, x, y) => [1,1,1]).getPixel(0,0)));
});

test ('imageMask correctly alters an image' , function(){
  const img = lib220.createImage(10,10,[1,1,1]);
  let outImg = imageMask(img, (img,x,y) => (y%3 === 0), [1,0,0]);
  assert(pixelEq(outImg.getPixel(4,0), [1,0,0]) && pixelEq(outImg.getPixel(2,5), [1,1,1]) && pixelEq(outImg.getPixel(1,9), [1,0,0]));
});

test ('imageMask correctly changes & returns a single pixel image' , function() {
  const img = lib220.createImage(1,1,[1,1,1]);
  let outImg = imageMask(img, (img,x,y) => (y === 0), [1,0,0]);
  assert(pixelEq(outImg.getPixel(0,0), [1,0,0]));
});

test ('imageMapCond correctly alters an image' , function() {
  const img = lib220.createImage(10,10,[1,1,1]);
  let outImg = imageMapCond(img, (img,x,y) => (y%2 === 0), (p) => ([p[0],p[1]*.2,p[2]*.5]));
  assert(pixelEq(outImg.getPixel(0,0), [1,0.2,0.5]) && pixelEq(outImg.getPixel(0,3), [1,1,1]) && pixelEq(outImg.getPixel(0,8), [1,0.2,0.5]));
});

test ('imageMapCond correctly changes & returns a single pixel image' , function() {
  const img = lib220.createImage(1,1,[1,1,1]);
  let outImg = imageMapCond(img, (img,x,y) => (y === 0), (p) => ([p[0]*.5,p[1]*.5,p[2]*.5]));
  assert(pixelEq(outImg.getPixel(0,0), [0.5,0.5,0.5]));
});


