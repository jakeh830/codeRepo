//takes in an expression and returns what it evaluates to
//interpExpression(state: State, e: Expr): number | boolean
function interpExpression(state, e) {
  if (e.kind === 'boolean' || e.kind === 'number') {
    return e.value;
  }
  else if (e.kind === 'operator') {
    let e1 = interpExpression(state, e.e1);
    let e2 = interpExpression(state, e.e2);
    let areNums = typeof(e1) === 'number' && typeof(e2) === 'number';
    let areBools = typeof(e1) === 'boolean' && typeof(e2) === 'boolean';
    if ((areNums || areBools) && e.op === '===') {
        return e1 === e2;
    }
    else if (areNums) {
      switch (e.op) {
        case '+': {return e1+e2;}
        case '-': {return e1-e2;}
        case '*': {return e1*e2;}
        case '/': {return e1/e2;}
        case '>': {return e1 > e2;}
        case '<': {return e1 < e2;}
        default: {
          console.log("error");
          assert(false);
        }
      }
    }
    else if (areBools) {
      switch (e.op) {
        case '&&': {return e1 && e2;}
        case '||': {return e1 || e2;}  
        default: {
          console.log("error");
          assert(false);
        }
      }
    }
    else {
      console.log("error");
      assert(false);
    }
  }
  else if (e.kind === 'variable') {
    if (!lib220.getProperty(state, e.name).found) {
      console.log("not found");
      assert(false);
    }
    return lib220.getProperty(state, e.name).value;
  }
  else {
    assert(false, 'Error- unknown e.kind');
  }
}

//evaluates a statement such as let or if and stores the values
//interpStatement(state: State, p: Stmt): void
function interpStatement(state, p) {
  switch (p.kind) {
    case 'let': {
      if (lib220.getProperty(state, p.name).found) {
        console.log("error- duplicate declarations");
        assert(false);
      }
      lib220.setProperty(state, p.name, interpExpression(state, p.expression));
      break;
    }
    case 'assignment': {
      if (lib220.getProperty(state, p.name).found === false) {
        console.log("error- unassigned var");
        assert(false);
      }
      lib220.setProperty(state, p.name, interpExpression(state, p.expression));
      break;
    }
    case 'if': {
      let blank = {};
      lib220.setProperty(blank, 'varVal', state);
      if (interpExpression(state, p.test)) {
        interpBlock(blank, p.truePart);
      }
      else {
        interpBlock(blank, p.falsePart);
      }
      break;
    }
    case 'while': {
      while (interpExpression(state, p.test)) {
        let blank = {};
        lib220.setProperty(blank, 'varVal', state);
        interpBlock(blank, p.body);
      }
      break;
    }
    case 'print': {
      console.log(interpExpression(state, p.expression));
      break;
    }
    default: {
      console.log("error- unknown statement");
      assert(false);
    }
  }
}

//interprets an entire program, by breaking it up into statements and blocks
//and evaluating them
//interpProgram(p: Stmt[]): State
function interpProgram(p) {
  let state = {};
  interpBlock(state, p);
  return state;
}

//interprets a block
//interpBlock(state, b)
function interpBlock(state, b) {
  b.forEach(e => {
    if (e.kind === 'assignment') {
      let tmp = state;
      while (!lib220.getProperty(tmp, e.name).found) {
        if (!lib220.getProperty(tmp, 'varVal').found) {
          console.log("error");
          assert(false);
        }
        tmp = tmp.varVal;
      }
      lib220.setProperty(tmp, e.name, interpExpression(tmp, e.expression));
    }
    else {
      interpStatement(state, e);
    }
  });
}

test("multiplication with a variable", function() {
  let r = interpExpression({ x: 10 }, parser.parseExpression("x * 2").value);
  assert(r === 20);
});
test("assignment", function() {
  let st = interpProgram(parser.parseProgram("let x = 10; x = 20;").value);
  assert(st.x === 20);
});
test("if", function() {
  let st = interpProgram(parser.parseProgram("let x = 10; if(true){x = 6;}else{}").value);
  assert(st.x === 6);
});
test("print", function() {
  let st = interpProgram(parser.parseProgram("let x = 9; print(x);").value);
  assert(true);
});
test("while", function() {
  let st = interpProgram(parser.parseProgram("let x = 5; while(x>0){x = x - 1;}").value);
  assert(st.x === 0);
});
