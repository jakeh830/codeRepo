// Returns a random int i where min <= i < max
function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

//generates a NxN array of values where each array is a random permutation of 0 to N
//generateInput(n: number): number[][]
function generateInput(n) {
  let arr = [];
  for (let i = 0; i < n; ++i) {
    arr.push(i);
  }
  let returnArr = [];
  for (let i = 0; i < n; ++i) {
    returnArr.push(shuffle(arr.slice(0, arr.length)));
  }
  return returnArr;
}

// randomly shuffles array and returns it, based off pseudo code of fisher-yates shuffle found 
// here https://en.wikipedia.org/wiki/Fisher%E2%80%93Yates_shuffle
//shuffle(arr: number[]): number[]
function shuffle(arr) {
  let k, temp, j = arr.length;
  while(--j > 0) {
    k = randomInt(0,j);
    temp = arr[k];
    arr[k] = arr[j];
    arr[j] = temp;
  }
  return arr;
}

//oracle(f: (companies: number[][], candidates: number[][]) => Hire[]): void
function oracle(f) {
  let numTests = 100; // Change this to some reasonably large value
  for (let i = 0; i < numTests; ++i) {
    let n = 10; // Change this to some reasonable size
    let companies = generateInput(n);
    let candidates = generateInput(n);
    let hires = f(companies, candidates);
    test('Hires length is correct', function() {
      assert(companies.length === hires.length);
    }); // Write more tests like this one

    test('each candidate and company is listed in hires exactly once', function() {
      let x = 0;
      for (let i = 0; i < n; ++i) {
        x += i;
      }
      let y = hires.reduce((acc, e) => (e.candidate+acc), 0);
      let z = hires.reduce((acc, e) => (e.company+acc), 0);
      assert(x === y && x === z);
    });

    test('no instabilities', function() {
      /*This function checks to ensure that there is not a single case within hires where both a company and a 
      candidate prefer each other over their current match.  It does so by going through each object in hires.
      For example, it would check an object in hires which has Company A and Candidate Z, making a matching pair.
      It would then check if Company A has any candidates that it prefers over Candidate Z, if so each of 
      these preferences is checked individually to see if they would prefer Company A over their own
      current match, say Company P.  If so, then the result is not stable, and the test fails*/
      //findInstability(): boolean
      function findInstability() {
        let instability = false;
        hires.forEach(i => {
          let curCand = i.candidate;
          let curComp = i.company;
          let x = candidates[curCand].indexOf(curComp);
          let y = companies[curComp].indexOf(curCand);
          instability = checkPrefs(x, companies, candidates, curCand, true);
          instability = checkPrefs(y, candidates, companies, curComp, false);
        });
        return instability;
      }

      /*This function will check the preferences of a company/candidate that it values above that of it's actual 
      pair match in hires. It will then check if any of the preferences themselves also prefer said 
      company/candidate above THEIR own match in hires.  If so, it will return true, false otherwise.
          c1 and c2 denote either a company or a candidate, depending on the order the parameters are inputted, 
          can change if a candiate or company's preferences are being checked, along with inputting curItem 
          and isCand correctly to reflect this change
            Quick example: checkPrefs(4, companies, candidates, curCandidate, true)
                would be the correct way of inputting that you want to check the first 4 preferences of candidate 
               "curCandidate" to see if any of these preferred companies also prefer curCandidate to their current 
               match
        */
        //checkPrefs(last: number, c1: number[][], c2: number[][], curItem: number, isCand: boolean): boolean
      function checkPrefs(last, c1, c2, curItem, isCand) {
        for (let j = 0; j < last; ++j) {
          //pref = candidate/company in curItem's preferences that is above curItem's current match in hires
          let pref = c1[c2[curItem][j]];
          let indexOfPref = c2[curItem][j];
          //finds pref's current match within hires
          let prefCurItem = findCurMatch(indexOfPref, isCand);
          if (pref.indexOf(curItem) < pref.indexOf(prefCurItem)) {
            return true;
          }
        }
        return false; 
      }

      /*takes in the index of either a company or a candidate, which is determined by isCand
      (true for candidate, false for company).
      Function will return the number denoting the match for the input company/candidate by checking through hires.
      Returns -1 if no match is found*/
      //findCurMatch(indexOfPref: number, isCand: boolean): number
      function findCurMatch(indexOfPref, isCand) {
        let match = -1;
        hires.forEach(i => {
          if (i.candidate === indexOfPref && !isCand) {
            match = i.company;
          }
          if (i.company === indexOfPref && isCand) {
            match = i.candidate;
          }
        });
        return match;
      }

    assert(!findInstability());
    });
  }
}

oracle(wheat1);
oracle(chaff1);